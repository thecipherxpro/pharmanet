// This component has been removed - push notifications are not supported
export default function NotificationPermissionPrompt() {
  return null;
}